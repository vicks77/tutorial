package interview;

public class BinarySearch {

    public static void main(String [] args)
    {

            int low=0;
            int counter=0;
            int key=4;
            int [] array={1,1,2,3,3,3,3,4,4};
            int sizeArray=array.length;
            int high=sizeArray-1;
int searchIndex=0;

while(low<=high) {
    int mid=(low+high)/2;
    if (key == array[mid]) {
        searchIndex=mid;
        break;
    } else if (key > array[mid]) {

        low = mid;
    } else {
        high = mid;
    }
}
              if(array[searchIndex]==array[searchIndex-1])
              {
                  searchIndex-=searchIndex;
              }

               for(int i=searchIndex;i<=high;i++ )
               {
                   if(array[i]==key)
                   {
                       counter++;

                   }



               }

        System.out.println(("Total count for 3"+counter));
        }

}
