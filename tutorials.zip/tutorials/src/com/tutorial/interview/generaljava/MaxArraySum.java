package com.tutorial.interview.generaljava;

public class MaxArraySum {

    public static void main(String [] args)
    {
        int [] array={-2,1,3,-4,5};
        int [] sum={0,0,0,0,0};
        int k=0;

        for(int i=0;i<array.length;i=i++)
        {
            for(int j=i+2;j<array.length;j=j+2)
            {
              sum[k]=array[i]+array[j];
            }
            k++;
        }

       for(int i=0;i<array.length;i++) {
           System.out.println("summm" + sum[i]);
       }

    }
}
