package com.tutorial.interview.generaljava;

public class MainClass {
static void  getObjectValue(Object obj)
    {
        System.out.println("Object method is called");
    }


}
