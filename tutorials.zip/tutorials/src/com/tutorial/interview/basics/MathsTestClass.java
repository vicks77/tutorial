package com.tutorial.interview.basics;

public class MathsTestClass  implements  MathInterface{
    public void  main()
    {
       // MathInterface f1=(y)->y%2==0?true:false;
      // System.out.println(f1.retValue(10));


    }
    @Override
    public boolean retValue(int x)
    {
        return false;
    }

    public  int getValue(String s)
    {
        return 2;
    }
}
