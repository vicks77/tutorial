package com.tutorial.interview.basics;

import java.util.stream.IntStream;

public class NumberGame {

    public boolean getPrimeNumer(int number)
    {
        return IntStream.rangeClosed(2, number/2).noneMatch(i -> number%i == 0);

    }



}
