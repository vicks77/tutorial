package com.tutorial.interview.basics;

@FunctionalInterface
public interface MathInterface {
    public boolean retValue(int x);
    default int getValue(String s)
    {
        return 1;
    }

    default  String getName()
    {
        return "Aniket";
    }
}
