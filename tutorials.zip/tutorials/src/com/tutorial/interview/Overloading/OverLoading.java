package com.tutorial.interview.Overloading;

public class OverLoading {

    public String getValue(Object obj)
    {
        return "Object is refered";
    }

    public String getValue(String str)
    {
        return "String is refered";
    }
    public String getValue(Integer x)
    {
        return "Integer is refered";
    }
}
