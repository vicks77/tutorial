package com.tutorial.interview.Overloading;

public class MainClass {
    public static void main(String[] args) {


    OverLoading overLoading = new OverLoading();
    System.out.println(overLoading.getValue(overLoading));
}
}
