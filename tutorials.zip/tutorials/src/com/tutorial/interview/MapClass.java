package com.tutorial.interview;

import java.util.HashMap;
import java.util.Map;

public class MapClass {

    public void iterateUsingMapApi()
    {
      Map<Integer,String> mapCollection=new HashMap<Integer,String>();
        mapCollection.put(1,"Kolkata");
        mapCollection.put(2,"Delhi");
        mapCollection.put(3,"Mumbai");
        mapCollection.put(4,"Bangalore");

        mapCollection.forEach((k,v)->System.out.print(k+":"+v));
        }}



