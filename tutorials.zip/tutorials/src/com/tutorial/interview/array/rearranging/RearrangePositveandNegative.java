package com.tutorial.interview.array.rearranging;

public class RearrangePositveandNegative {

    public static void main(String [] args)
    {
        int arr[] = {-1, 2, -3, 4, 5, 6, -7, 8, 9};
        int temp=0;
        for(int i=0;i<arr.length;i++)
        {

               if (arr[i] < 0 && arr[i + 1] > 0) {
                   // i++;
                   temp = arr[i];
                   arr[i] = arr[i + 1];
                   arr[i + 1] = temp;

               }

        }

        System.out.println("ARearranged array"+arr.toString());


    }
}
