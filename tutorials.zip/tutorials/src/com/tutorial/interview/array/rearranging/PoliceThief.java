package com.tutorial.interview.array.rearranging;

public class PoliceThief {
    public static void main(String [] args)
    {
        int k=1;
        int counter=0;
        boolean flag=true;
        Character [] arrayInfo={'P','P','T','P','T','P','T','T','P'};
        for(int i=0;i<arrayInfo.length;i++)
        {
            if(arrayInfo[0]=='P' && flag==true)
            {
                flag=false;
                if(arrayInfo[k]=='T')
                {
                    counter++;


                }

            }
            else
            {

            if(arrayInfo[i]=='P')
            {
                if(arrayInfo[i-k]=='T')
                {
                    counter++;
                }
                if(arrayInfo[i-k]!='T'&& arrayInfo[i+k]=='T')
                {
                    counter++;
                }
            }}
        }
        System.out.println("Counter"+counter);
    }

}
