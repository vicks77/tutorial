package com.tutorial.interview;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class MainClass {

    public static void main(String args[])
    {
      List<Integer> list=new ArrayList<Integer>();

      list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        List<String> stringList=new ArrayList<String>();
        stringList.add("Kolkata");
        stringList.add("Delhi");
        stringList.add("Mumbai");
        stringList.add("Bangalore");
       // list.stream().filter(n -> n % 2 == 0).forEach(System.out::println);
long numberOfAdd=list.stream().filter(m->m>3).count();
List<Integer> noOfitem=list.stream().filter(m->m>2).collect(Collectors.toList());
//list.stream().filter(())
//List<String> updatedList=stringList.stream().map(i->i.concat(" part of India")).collect(Collectors.toList());
//Stream<Integer> value=list.stream().filter(i->i%2==0?true:false);
//MapClass mapClass=new MapClass();
//mapClass.iterateUsingMapApi();
//System.out.println(value);
System.out.println(noOfitem);
    }
}
