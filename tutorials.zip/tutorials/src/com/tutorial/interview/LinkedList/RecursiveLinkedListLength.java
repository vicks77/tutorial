// Recursive Java program to count number of nodes in
// a linked list

/* Linked list Node*/
package com.tutorial.interview.LinkedList;

// Linked List class
class RecursiveLinked
{
    Node head; // head of list

    /* Inserts a new Node at front of the list. */
    public void push(int new_data)
    {
		/* 1 & 2: Allocate the Node &
				Put in the data*/
        Node new_node = new Node(new_data);

        /* 3. Make next of new Node as head */
        new_node.next = head;

        /* 4. Move the head to point to new Node */
        head = new_node;
    }

    /* Returns count of nodes in linked list */
    public int getCountRec(Node node)
    {
        // Base case
        if (node == null)
            return 0;

        // Count is this node plus rest of the list
        return 1 + getCountRec(node.next);
    }

    /* Wrapper over getCountRec() */
    public int getCount()
    {
        return getCountRec(head);
    }

    /* Driver program to test above functions. Ideally
    this function should be in a separate user class.
    It is kept here to keep code compact */
    public static void main(String[] args)
    {
        /* Start with the empty list */
        LinkedList llist = new LinkedList();
        llist.push(1);
        llist.push(3);
        llist.push(1);
        llist.push(2);
        llist.push(1);
        llist.push(5);
        llist.push(6);
        llist.push(7);


        System.out.println("Count of nodes is " +
                llist.getCount());
    }
}
