package com.tutorial.interview.multithreading;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Consumer implements  Runnable{
    private final BlockingQueue shaBlockingQueue;

    public Consumer(BlockingQueue sharedQueue) {
        this.shaBlockingQueue = sharedQueue;


    }

    @Override
    public void run() {

        while(true)
        {
            try {
                System.out.println(shaBlockingQueue.take());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
