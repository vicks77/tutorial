package com.tutorial.interview.multithreading;

public class OddEven  {



    public static void main(String [] args)
    {

        EvenOddNumberImpl evenOddNumber=new EvenOddNumberImpl();

        Thread threadOdd=new Thread(new Runnable() {
            @Override
            public void run() {
                evenOddNumber.getOddNumber();


            }
        });

Thread threadEven=new Thread(new Runnable() {
    @Override
    public void run() {
        evenOddNumber.getEvenNumber();
    }
});
        threadEven.start();
        threadOdd.start();


        try {
            threadOdd.join();
            threadEven.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }
}
