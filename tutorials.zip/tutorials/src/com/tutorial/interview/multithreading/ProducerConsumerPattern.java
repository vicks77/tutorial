package com.tutorial.interview.multithreading;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class ProducerConsumerPattern {

    public static void main(String [] args)
    {
        BlockingQueue sharedQueue=new LinkedBlockingDeque();
        //Creating Producer and Consumer thread
        Thread prodThread=new Thread(new Producer(sharedQueue));
        Thread consmerThread=new Thread((new Consumer(sharedQueue)));
        prodThread.start();
        consmerThread.start();

    }
}
