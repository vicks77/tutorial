package com.tutorial.interview.multithreading;

import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable{
    private final BlockingQueue shaBlockingQueue;
    public Producer(BlockingQueue sharedQueue) {
        this.shaBlockingQueue = sharedQueue;
    }

    @Override
    public void run() {
for(int i=0;i<10;i++)
{
    System.out.println("Producer produces"+i);
    try {
        shaBlockingQueue.put(i);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
}
    }
}
