package com.tutorial.interview.multithreading;

public class EvenOddNumberImpl  {
    boolean odd;
    int count=1;
    int MAX=20;
    public void getEvenNumber()
    {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        synchronized(this){
        while(count<MAX)
       {
        System.out.println("Checking even loop");
           while(odd==false)
        {



            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
           System.out.println("Even number "+count);
           count++;
           odd=true;
           notify();



       }}

    }

    public void getOddNumber()
    {
        synchronized(this){
            while(count<MAX)
            {
                System.out.println("Checking odd loop");
                while(odd==true)
                {


                    try {
                        wait();


                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
                System.out.println("Odd  number "+count);
                count++;
                odd=false;
                notify();
 }}
    }
}
