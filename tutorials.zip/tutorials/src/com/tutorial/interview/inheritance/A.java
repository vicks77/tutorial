package com.tutorial.interview.inheritance;

public class A {
    public void getValue()
    {
        System.out.println("I am A");
    }
}
