package com.tutorial.interview.inheritance;

public class B extends A{
   /* public void getValue()
    {
       super.getValue();
        System.out.println("I am B");
    }*/
}
