package com.tutorial.interview.inheritance;

public class MainClass {
    public static void main(String [] args)
    {
        A a=new B();
        B b =new B();
       // b.getValue();
        a.getValue();
    }
}
