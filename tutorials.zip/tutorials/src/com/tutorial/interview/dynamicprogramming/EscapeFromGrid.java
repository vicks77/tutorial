package com.tutorial.interview.dynamicprogramming;

import java.io.*;
import java.util.*;


class Cell {
    int x, y, dist;

    public Cell(int x, int y, int dist) {
        this.x = x;
        this.y = y;
        this.dist = dist;
    }
}
public class EscapeFromGrid {


    public static int solveIt(int r, int c, int[][] grid) {
        int startX = 0,startY = 0;
        if (grid == null || grid.length == 0)
            return 0;
        search: for(int i = 0; i < grid.length;i++){
            for(int j = 0; j < grid[0].length;j++){
                if(grid[i][j] == 2){
                    startX = i;
                    startY = j;
                    break search;
                }
            }
        }


        int dis[][] = new int[r][c];
        Queue<Cell> q = new ArrayDeque<>();
        q.add(new Cell(startX, startY, 0));
        boolean mark[][] = new boolean[r][c];

        for(int i = 0; i < mark.length;i++){
            Arrays.fill(mark[i],false);
        }

        dis[0][0] = grid[0][0];
        // System.out.println("q.size():" + q.size());
        while (q.size() > 0) {
            Cell cell = q.poll();
            //System.out.println(cell.x + "," + cell.y );
            if ((cell.x == 0 || cell.x == r - 1) && (cell.y >= 0 && cell.y < c))
                return cell.dist;

            if (cell.x + 1 < r && grid[cell.x + 1][cell.y] != 1) {
                if (mark[cell.x + 1][cell.y])
                    continue;
                mark[cell.x + 1][cell.y] = true;
                q.add(new Cell(cell.x, cell.y, cell.dist + 1));
            }
            if (cell.x - 1 >= 0 && grid[cell.x - 1][cell.y] != 1) {
                if (mark[cell.x - 1][cell.y])
                    continue;
                mark[cell.x - 1][cell.y] = true;
                q.add(new Cell(cell.x - 1, cell.y, cell.dist + 1));
            }
            if (cell.y + 1 < c && grid[cell.x][cell.y + 1] != 1) {
                if (mark[cell.x][cell.y + 1])
                    continue;
                mark[cell.x][cell.y + 1] = true;
                q.add(new Cell(cell.x, cell.y + 1, cell.dist + 1));
            }
            if (cell.y - 1 >= 0 && grid[cell.x][cell.y - 1] != 1) {
                if (mark[cell.x][cell.y - 1])
                    continue;
                mark[cell.x][cell.y - 1] = true;
                q.add(new Cell(cell.x, cell.y - 1, cell.dist + 1));
            }

        }
        return -1;
    }



    public static void main(String[] args) throws Exception {
        int[][] G;
        int n, m;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(System.out);
        String[] s = br.readLine().split(" ");
        n = Integer.parseInt(s[0]);
        m = Integer.parseInt(s[1]);
        G = new int[n][m];
        for (int i = 0; i < n; i++) {
            String temp[] = br.readLine().trim().split(" ");
            for (int j = 0; j < m; j++) G[i][j] = Integer.parseInt(temp[j]);
        }
        out.println(solveIt(n, m, G));
        br.close();
        out.close();
    }
}
